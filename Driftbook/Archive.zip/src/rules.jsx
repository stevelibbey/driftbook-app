// Modular rule engine configuration
// Handles brightness, contrast, note events, etc.
